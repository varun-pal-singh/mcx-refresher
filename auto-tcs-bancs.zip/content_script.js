// This script runs on the specified page to automate button clicks.

console.log("Margin Utilization Auto-clicker script loaded.");

const ID = 'form#RSK335ID input#Search[value="Search"]';

function clickSearchButton() {
  const searchButton = document.querySelector(ID);
  console.log("searchButton", searchButton);

  if (searchButton) {
    searchButton.click();
    console.log("Search button clicked successfully.");
  } else {
    console.error("Could not find the search button. The selector may be outdated.");
  }
}

setTimeout(() => {
  clickSearchButton(); // Click immediately on load
  setInterval(clickSearchButton, 60000);
}, 3000); 